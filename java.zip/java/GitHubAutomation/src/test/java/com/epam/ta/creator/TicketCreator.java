package com.epam.ta.creator;
import com.epam.ta.model.Ticket;
import com.epam.ta.util.TestDataReader;

public class TicketCreator {
    public static String TESTDATA_TICKET_CAPACITY = "testdata.ticket.capacity";
    public static String TESTDATA_TICKET_TICKET = "testdata.ticket.ticket";
    public static String TESTDATA_TICKET_PRICE = "testdata.ticket.price";

    public static Ticket getTicketWithAllData(){
        return new Ticket(
                Integer.parseInt(TestDataReader.getTestData(TESTDATA_TICKET_CAPACITY)),
                TestDataReader.getTestData(TESTDATA_TICKET_TICKET),
                Integer.parseInt(TestDataReader.getTestData(TESTDATA_TICKET_PRICE)));
    }

}
