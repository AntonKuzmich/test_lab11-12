package com.epam.ta.model;
import java.util.Objects;


public class Adress {
    public Adress(String name, int number, String street, int flat, String city, int zip) {
        this.name = name;
        this.number = number;
        this.street = street;
        this.flat = flat;
        this.city = city;
        this.zip = zip;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public int getFlat() {
        return flat;
    }

    public void setFlat(int flat) {
        this.flat = flat;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public int getZip() {
        return zip;
    }

    public void setZip(int zip) {
        this.zip = zip;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Adress)) return false;
        Adress adress = (Adress) o;
        return number == adress.number && flat == adress.flat && zip == adress.zip && name.equals(adress.name) && street.equals(adress.street) && city.equals(adress.city);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, number, street, flat, city, zip);
    }

    private String name;
    private int number;
    private String street;
    private int flat;
    private String city;
    private int zip;
}
