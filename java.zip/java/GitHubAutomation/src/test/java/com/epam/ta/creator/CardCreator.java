package com.epam.ta.creator;
import com.epam.ta.util.TestDataReader;
import com.epam.ta.model.Card;

public class CardCreator {

    public static String TESTDATA_CARD_CVV = "testdata.card.cvv";
    public static String TESTDATA_CARD_NUMBER = "testdata.card.number";
    public static String TESTDATA_CARD_NAME = "testdata.card.name";
    public static String TESTDATA_CARD_DATE = "testdata.card.date";

public static Card getCardWithAllData(){
return new Card(
        Integer.parseInt(TestDataReader.getTestData(TESTDATA_CARD_CVV)),
        TestDataReader.getTestData(TESTDATA_CARD_NUMBER),
        TestDataReader.getTestData(TESTDATA_CARD_NAME),
        Integer.parseInt(TestDataReader.getTestData(TESTDATA_CARD_DATE)));

}
}
