package com.epam.ta.test;
import com.epam.ta.creator.*;
import com.epam.ta.model.*;
import com.epam.ta.page.AliBasketPage;
import com.epam.ta.page.AliCategoryPage;
import com.epam.ta.page.AliHomePage;
import com.epam.ta.page.AliOrderPage;
import org.junit.Assert;
import org.junit.Test;


public class UserAccessTests extends CommonConditions {
    private Search TEST_SEARCH= SearchCreator.getSearchWithAllData();
    private User TEST_USER = UserCreator.getUserWithAllData();
    private Adress TEST_ADRESS = AdressCreator.getAdressWithAllData();
    private Ticket TEST_TICKET = TicketCreator.getTicketWithAllData();
    private Card TEST_CARD = CardCreator.getCardWithAllData();
    @Test
    public void successSearchResult(){
        Search search=SearchCreator.getSearchWithAllData();
        new AliHomePage(driver)
                .waitForHomePageToLoad()
                .openPage()
                .searchThing(TEST_SEARCH);
    }
    @Test
    public void checkNameOrder(){
        new AliHomePage(driver)
                .openPage()
                .loginIntoAccount(TEST_USER)
                .openBasketPage();
        new AliBasketPage(driver)
                .moveToOrder();
        new AliOrderPage(driver)
                .AddCard(TEST_CARD);
    }
    @Test
    public void checkNameAdress(){
        new AliHomePage(driver)
                .openPage()
                .loginIntoAccount(TEST_USER)
                .openBasketPage();
        new AliBasketPage(driver)
                .moveToOrder();
        new AliOrderPage(driver)
                .AddNewAdress(TEST_ADRESS);
    }
    @Test
    public void checkZipAdress(){
        new AliHomePage(driver)
                .openPage()
                .loginIntoAccount(TEST_USER)
                .openBasketPage();
        new AliBasketPage(driver)
                .moveToOrder();
        new AliOrderPage(driver)
                .AddNewAdress(TEST_ADRESS);
    }
    @Test
    public void checkCapacityOrder(){
        new AliHomePage(driver)
                .openPage()
                .loginIntoAccount(TEST_USER)
                .openBasketPage();
        new AliBasketPage(driver)
                .moveToOrder();
        new AliOrderPage(driver)
                .AddCapacity(TEST_TICKET);
    }
    @Test
    public void checkTicketOrder(){
        new AliHomePage(driver)
                .openPage()
                .loginIntoAccount(TEST_USER)
                .openBasketPage();
        new AliBasketPage(driver)
                .moveToOrder();
        new AliOrderPage(driver)
                .AddTicket(TEST_TICKET);
    }
    @Test
    public void checkCardNumberOrder(){
        new AliHomePage(driver)
                .openPage()
                .loginIntoAccount(TEST_USER)
                .openBasketPage();
        new AliBasketPage(driver)
                .moveToOrder();
        new AliOrderPage(driver)
                .AddCard(TEST_CARD);
    }
    @Test
    public void checkMinPriceCategory(){
        new AliHomePage(driver)
                .openPage()
                .loginIntoAccount(TEST_USER)
                .openCategoryPage();
        new AliCategoryPage(driver)
                .AddTicket(TEST_TICKET);

    }
    @Test
    public void checkCapacityBasket(){
        new AliHomePage(driver)
                .openPage()
                .loginIntoAccount(TEST_USER)
                .openBasketPage();
        new AliBasketPage(driver)
                .addCapacityBasket();
    }
}


