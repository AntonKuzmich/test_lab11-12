package com.epam.ta.test;
import com.epam.ta.creator.*;
import com.epam.ta.model.*;
import com.epam.ta.page.*;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.PageFactory;


public class UserAccessTests extends CommonConditions {
    private Search TEST_SEARCH= SearchCreator.getSearchWithAllData();
    private User TEST_USER = UserCreator.getUserWithAllData();
    private Adress TEST_ADRESS = AdressCreator.getAdressWithAllData();
    private Ticket TEST_TICKET = TicketCreator.getTicketWithAllData();
    private Card TEST_CARD = CardCreator.getCardWithAllData();
    
    @Test
    public void successSearchResult(){
        chromeoptions=new ChromeOptions();
        chromeoptions.addArguments("user-data-dir=C:\\Users\\anton\\AppData\\Local\\Google\\Chrome\\User Data\\Default");
        driver=new ChromeDriver(chromeoptions);
            AliHomePage searchresult=new AliHomePage(driver)
                .waitForHomePageToLoad()
                .openPage()
                .searchThing(TEST_SEARCH);
        driver.quit();
        driver = null;
    }
    @Test
    public void checkMinPriceCategory(){
        chromeoptions=new ChromeOptions();
        chromeoptions.addArguments("user-data-dir=C:\\Users\\anton\\AppData\\Local\\Google\\Chrome\\User Data\\Default");
        driver=new ChromeDriver(chromeoptions);
        AliHomePage searchresult=new AliHomePage(driver)
                .waitForHomePageToLoad()
                .openPage()
                .openCategoryPage();
        new AliCategoryPage(driver)
                .AddTicket(TEST_TICKET);
        driver.quit();
        driver = null;

    }
    @Test
    public void checkNameAdress() throws InterruptedException {
        chromeoptions=new ChromeOptions();
        chromeoptions.addArguments("user-data-dir=C:\\Users\\anton\\AppData\\Local\\Google\\Chrome\\User Data\\Default");
        driver=new ChromeDriver(chromeoptions);
        AliHomePage searchresult= new AliHomePage(driver)
                .openPage()
                .openAccountPage();
        new AliAccountPage(driver)
                .changeAdress(TEST_ADRESS);
        driver.quit();
        driver = null;
    }
    @Test
    public void checkZipAdress() throws InterruptedException {
        chromeoptions=new ChromeOptions();
        chromeoptions.addArguments("user-data-dir=C:\\Users\\anton\\AppData\\Local\\Google\\Chrome\\User Data\\Default");
        driver=new ChromeDriver(chromeoptions);
        AliHomePage searchresult= new AliHomePage(driver)
                .openPage()
                .openAccountPage();
        new AliAccountPage(driver)
                .changeAdress(TEST_ADRESS);
        driver.quit();
        driver = null;
    }
    @Test
    public void checkFlatAdress() throws InterruptedException {
        chromeoptions=new ChromeOptions();
        chromeoptions.addArguments("user-data-dir=C:\\Users\\anton\\AppData\\Local\\Google\\Chrome\\User Data\\Default");
        driver=new ChromeDriver(chromeoptions);
        AliHomePage searchresult= new AliHomePage(driver)
                .openPage()
                .openAccountPage();
        new AliAccountPage(driver)
                .changeAdress(TEST_ADRESS);
        driver.quit();
        driver = null;
    }
    @Test
    public void checkCapacityOrder() throws InterruptedException {
        chromeoptions=new ChromeOptions();
        chromeoptions.addArguments("user-data-dir=C:\\Users\\anton\\AppData\\Local\\Google\\Chrome\\User Data\\Default");
        driver=new ChromeDriver(chromeoptions);
        AliHomePage searchresult=new AliHomePage(driver)
                .openBasketPage();
        new AliBasketPage(driver)
                .CapacityAdd();
        driver.quit();
        driver = null;
    }
    @Test
    public void checkCardNumberOrder() throws InterruptedException {
        chromeoptions=new ChromeOptions();
        chromeoptions.addArguments("user-data-dir=C:\\Users\\anton\\AppData\\Local\\Google\\Chrome\\User Data\\Default");
        driver=new ChromeDriver(chromeoptions);
        AliHomePage searchresult=new AliHomePage(driver)
                .openPage()
                .openBasketPage();
        Thread.sleep(5000);
        new AliBasketPage(driver)
                .OrderAll();
        Thread.sleep(5000);
        new AliOrderPage(driver)
                .AddCard(TEST_CARD);
        driver.quit();
        driver = null;
    }
    @Test
    public void checkCardCVVOrder() throws InterruptedException {
        chromeoptions=new ChromeOptions();
        chromeoptions.addArguments("user-data-dir=C:\\Users\\anton\\AppData\\Local\\Google\\Chrome\\User Data\\Default");
        driver=new ChromeDriver(chromeoptions);
        AliHomePage searchresult=new AliHomePage(driver)
                .openPage()
                .openBasketPage();
        Thread.sleep(5000);
        new AliBasketPage(driver)
                .OrderAll();
        Thread.sleep(5000);
        new AliOrderPage(driver)
                .AddCard(TEST_CARD);
        driver.quit();
        driver = null;
    }
}


