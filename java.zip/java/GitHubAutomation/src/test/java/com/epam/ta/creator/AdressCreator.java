package com.epam.ta.creator;
import com.epam.ta.model.Adress;
import com.epam.ta.util.TestDataReader;

public class AdressCreator {
    public static String TESTDATA_ADRESS_NAME = "testdata.adress.name";
    public static String TESTDATA_ADRESS_NUMBER = "testdata.adress.number";
    public static String TESTDATA_ADRESS_STREET = "testdata.adress.street";
    public static String TESTDATA_ADRESS_FLAT = "testdata.adress.flat";
    public static String TESTDATA_ADRESS_CITY = "testdata.adress.city";
    public static String TESTDATA_ADRESS_ZIP = "testdata.adress.zip";

    public static Adress getAdressWithAllData() {
return new Adress(
        TestDataReader.getTestData(TESTDATA_ADRESS_NAME),
        Integer.parseInt(TestDataReader.getTestData(TESTDATA_ADRESS_FLAT)),
        TestDataReader.getTestData(TESTDATA_ADRESS_STREET),
        Integer.parseInt(TestDataReader.getTestData(TESTDATA_ADRESS_ZIP)),
        TestDataReader.getTestData(TESTDATA_ADRESS_CITY),
        Integer.parseInt(TestDataReader.getTestData(TESTDATA_ADRESS_NUMBER)));
    }
}
