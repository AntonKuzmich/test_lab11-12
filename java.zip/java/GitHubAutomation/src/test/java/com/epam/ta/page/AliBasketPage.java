package com.epam.ta.page;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class AliBasketPage extends AbstractPage {

    @FindBy(xpath = "/html/body/div/div/div[4]/div/div/div/div[2]/div/div/div/div/div/div[4]/button")
    WebElement buttonSelectAll;

    @FindBy(xpath = "/html/body/div/div/div[4]/div/div/div/div[2]/div/div/div/div/div/div[6]/button")
    WebElement buttonOrderAll;

    @FindBy(xpath = "/html/body/div/div/div[4]/div/div/div/div[1]/div[4]/div[1]/div/div[1]/div[2]/div[4]/div/button[2]")
    WebElement buttonAddCapacity;


    public AliBasketPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        logger.info("Opened HomePage");
    }
    public AliBasketPage moveToOrder() {
        buttonSelectAll.click();
        buttonOrderAll.click();
        return this;
    }
    public AliBasketPage addCapacityBasket(){
        buttonAddCapacity.click();
        return this;
    }
}
