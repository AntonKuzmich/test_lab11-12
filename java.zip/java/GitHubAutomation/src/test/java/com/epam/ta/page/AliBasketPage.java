package com.epam.ta.page;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class AliBasketPage extends AbstractPage {

    @FindBy(xpath = "//button[@class='snow-ali-kit_Button-Floating__button__ph4zrl snow-ali-kit_Button__button__1yq34d snow-ali-kit_Button__sizeL__1yq34d snow-ali-kit_Button__full__1yq34d SnowShoppingcartTotalPrice_ConfirmButton__button__e0yba' and 'Выбрать всё']")
    WebElement buttonSelectAll;

    @FindBy(xpath = "//button[@class='snow-ali-kit_Button-Secondary__button__4468ot snow-ali-kit_Button__button__1yq34d snow-ali-kit_Button__sizeM__1yq34d SnowShoppingcartProductList_BuySellerProducts__buyBtn__1o9fr']")
    WebElement buttonOrderAll;
    @FindBy(xpath = "//button[2][@class='snow-ali-kit_Button-Tertiary__button__jio9gc snow-ali-kit_Button__button__1yq34d snow-ali-kit_Button__sizeS__1yq34d SnowShoppingcartProductList_ProductNumAction__button__1yo4e']")
    WebElement capacityAdd;
    public AliBasketPage(WebDriver driver) {
        this.driver=driver;
        PageFactory.initElements(driver, this);
        logger.info("Opened HomePage");
    }
    public AliBasketPage SelectAll() {
        buttonSelectAll.click();
        return this;
    }
    public AliBasketPage OrderAll(){
        buttonOrderAll.click();
        return this;
    }
    public AliBasketPage CapacityAdd()
    {
        capacityAdd.click();
        return this;
    }

    @Override
    public AbstractPage waitForPageToLoad() {
        return super.waitForPageToLoad();
    }
}
