package com.epam.ta.page;
import com.epam.ta.model.Adress;
import com.epam.ta.model.Card;
import com.epam.ta.model.Ticket;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class AliOrderPage extends AbstractPage {

    @FindBy(xpath = "/html/body/div[1]/div/div[2]/div/div/div[1]/div/div[1]/div/div/div/div[2]/button[2]")
    WebElement buttonAddNewAdress;

    @FindBy(xpath = "/html/body/div[4]/div/div[2]/div/div/div/div[2]/button[2]")
    WebElement buttonChangeAdress;

    @FindBy(xpath = "/html/body/div[3]/div/div[2]/form/div[2]/div/div[1]/label/div/input")
    WebElement inputNameOnAdress;

    @FindBy(xpath = "/html/body/div[3]/div/div[2]/form/div[3]/div/div[2]/div[2]/div[2]/label/div/input")
    WebElement inputZipOnAdress;

    @FindBy(xpath = "/html/body/div[3]/div/div[2]/form/div[3]/div/div[1]/div[1]/label/div/input")
    WebElement inputRegionOnAdress;

    @FindBy(xpath = "/html/body/div[3]/div/div[2]/form/div[3]/div/div[2]/div[1]/div/label/div/input")
    WebElement inputStreetOnAdress;

    @FindBy(xpath = "/html/body/div[3]/div/div[2]/form/div[3]/div/div[1]/div[2]/div/label/div/input")
    WebElement inputCityOnAdress;

    @FindBy(xpath = "/html/body/div[3]/div/div[2]/form/div[3]/div/div[2]/div[2]/div[1]/label/div/input")
    WebElement inputFlatOnAdress;

    @FindBy(xpath = "/html/body/div[3]/div/div[2]/form/div[2]/div/div[2]/div[2]/label/div/input")
    WebElement inputNumberOnAdress;

    @FindBy(xpath = "/html/body/div/div/div[2]/div/div/div[2]/div/div/div[1]/div/div/div[4]/div[2]/div[1]/span/input")
    WebElement inputTicketText;

    @FindBy(xpath = "/html/body/div/div/div[2]/div/div/div[1]/div/div[3]/div/div/div/div/div/div[2]/div/div[3]/div/div/div/input")
    WebElement inputCapacity;

    @FindBy(xpath = "/html/body/div/div/div[2]/div/div/div[2]/div/div/div[1]/div/div/div[4]/div[2]/div[2]/button")
    WebElement buttonInputTicketText;

    @FindBy(xpath = "/html/body/div/div/div[2]/div/div/div[1]/div/div[2]/div/span")
    WebElement buttonChangeCard;

    @FindBy(xpath = "/html/body/div[3]/div/div[2]/div/div/section/div")
    WebElement buttonAddCard;

    @FindBy(xpath = "/html/body/div[3]/div/div[2]/div/div/section/section/form/div[1]/div[1]/div[2]/input")
    WebElement inputNumberOfCard;

    @FindBy(xpath = "/html/body/div[3]/div/div[2]/div/div/section/section/form/div[1]/div[1]/div[3]/div[1]/input")
    WebElement inputNameOfCard;

    @FindBy(xpath = "/html/body/div[3]/div/div[2]/div/div/section/section/form/div[1]/div[1]/div[3]/div[2]/input")
    WebElement inputDateOfCard;

    @FindBy(xpath = "/html/body/div[3]/div/div[2]/div/div/section/section/form/div[1]/div[2]/div/div/input")
    WebElement inputCVVOfCard;

    @FindBy(xpath = "/html/body/div[3]/div/div[2]/div/div/section/section/form/footer/div/button[1]")
    WebElement buttonAcceptOfCard;

    public AliOrderPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        logger.info("Opened HomePage");
    }
    public AliOrderPage AddNewAdress(Adress adress) {
        buttonAddNewAdress.click();
        buttonChangeAdress.click();
        inputNameOnAdress.sendKeys(adress.getName());
        inputNumberOnAdress.sendKeys(String.valueOf(adress.getNumber()));
        inputStreetOnAdress.sendKeys(adress.getStreet());
        inputFlatOnAdress.sendKeys(String.valueOf(adress.getFlat()));
        inputCityOnAdress.sendKeys(adress.getCity());
        inputZipOnAdress.sendKeys(String.valueOf(adress.getZip()));
        return this;
    }

    public AliOrderPage AddCapacity(Ticket ticket) {
        inputCapacity.sendKeys(String.valueOf(ticket.getCapacity()));
        return this;
    }

    public AliOrderPage AddTicket(Ticket ticket) {
        inputTicketText.sendKeys(ticket.getTicket());
        buttonInputTicketText.click();
        return this;
    }

    public AliOrderPage AddCard(Card card) {
        buttonChangeCard.click();
        buttonAddCard.click();
        inputCVVOfCard.sendKeys(String.valueOf(card.getCvv()));
        inputNumberOfCard.sendKeys(String.valueOf(card.getNumber()));
        inputNameOfCard.sendKeys(card.getName());
        inputDateOfCard.sendKeys(String.valueOf(card.getDate()));
        buttonAcceptOfCard.click();
        return this;
    }
}
