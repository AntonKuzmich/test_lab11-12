package com.epam.ta.page;
import com.epam.ta.model.Adress;
import com.epam.ta.model.Card;
import com.epam.ta.model.Ticket;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class AliOrderPage extends AbstractPage {

    @FindBy(xpath = "//button[2][@class='ali-kit_Button__button__18ub7i ali-kit_Button__size-s__18ub7i contained ali-kit_Button__default__18ub7i CheckoutShippingMethod_AddressItem__button__zhitf' and 'Выбрать другой адрес']")
    WebElement buttonAddNewAdress;

    @FindBy(xpath = "//button[@class='ali-kit_Button__button__18ub7i ali-kit_Button__size-s__18ub7i contained ali-kit_Button__default__18ub7i CheckoutShippingMethod_AddressListItem__button__1dxo6' and 'Редактировать']")
    WebElement buttonChangeAdress;

    @FindBy(xpath = "//input[@id='contactPerson']")
    WebElement inputNameOnAdress;

    @FindBy(xpath = "//input[@id='zip']")
    WebElement inputZipOnAdress;

    @FindBy(xpath = "//input[@id='province']")
    WebElement inputRegionOnAdress;

    @FindBy(xpath = "//input[@id='address']")
    WebElement inputStreetOnAdress;

    @FindBy(xpath = "//input[@id='city']")
    WebElement inputCityOnAdress;

    @FindBy(xpath = "//input[@id='address2']")
    WebElement inputFlatOnAdress;

    @FindBy(xpath = "//input[@id='mobileNo']")
    WebElement inputNumberOnAdress;

    @FindBy(xpath = "//input[@class='CheckoutOrderOverview_CouponCodeInputBox__input__y3cn2']")
    WebElement inputTicketText;

    @FindBy(xpath = "//input[@class='CheckoutItemList_NumActionGroup__numInput__ps8di']")
    WebElement inputCapacity;

    @FindBy(xpath = "//button[@class='ali-kit_Button__button__18ub7i ali-kit_Button__size-m__18ub7i ali-kit_Button__outlined__18ub7i ali-kit_Button__primary__18ub7i ali-kit_Button__full__18ub7i CheckoutOrderOverview_CouponCodeInputBox__bnt__y3cn2']")
    WebElement buttonInputTicketText;

    @FindBy(xpath = "//span[@class='ali-kit_Base__base__104pa1 ali-kit_Base__info__104pa1 ali-kit_Base__semiBold__104pa1 ali-kit_Button__button__1b6jiz ali-kit_Button__size-xs__1b6jiz CheckoutPaymentMethod_MainPanel__button__1han1']")
    WebElement buttonChangeCard;

    @FindBy(xpath = "//p[@class='ali-kit_Base__base__104pa1 ali-kit_Base__info__104pa1 ali-kit_Base__semiBold__104pa1 ali-kit_Button__button__1b6jiz ali-kit_Button__size-s__1b6jiz CheckoutPaymentMethod_BoundBankCardList__addCardButton__7dswx']")
    WebElement buttonAddCard;

    @FindBy(xpath = "//input[@id='cardNumber']")
    WebElement inputNumberOfCard;

    @FindBy(xpath = "//input[@id='cardholder']")
    WebElement inputNameOfCard;

    @FindBy(xpath = "//input[@id='cardExpire']")
    WebElement inputDateOfCard;

    @FindBy(xpath = "//input[@id='cardCvv']")
    WebElement inputCVVOfCard;

    @FindBy(xpath = "//button[@class='ali-kit_Button__button__18ub7i ali-kit_Button__size-l__18ub7i contained ali-kit_Button__primary__18ub7i CheckoutPaymentMethod_ButtonRow__control__baial CheckoutPaymentMethod_ButtonRow__controlAccent__baial' and @data-spm-anchor-id='a2g2w.placeorder.0.i25.618f4aa6f4ib65']")
    WebElement buttonAcceptOfCard;

    public AliOrderPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        logger.info("Opened HomePage");
    }
    public AliOrderPage AddNewAdress(Adress adress) {
        buttonAddNewAdress.click();
        buttonChangeAdress.click();
        inputNameOnAdress.sendKeys(adress.getName());
        inputNumberOnAdress.sendKeys(String.valueOf(adress.getNumber()));
        inputStreetOnAdress.sendKeys(adress.getStreet());
        inputFlatOnAdress.sendKeys(String.valueOf(adress.getFlat()));
        inputCityOnAdress.sendKeys(adress.getCity());
        inputZipOnAdress.sendKeys(String.valueOf(adress.getZip()));
        return this;
    }

    public AliOrderPage AddCapacity(Ticket ticket) {
        inputCapacity.sendKeys(String.valueOf(ticket.getCapacity()));
        return this;
    }

    public AliOrderPage AddTicket(Ticket ticket) {
        inputTicketText.sendKeys(ticket.getTicket());
        buttonInputTicketText.click();
        return this;
    }

    public AliOrderPage AddCard(Card card) {
        buttonChangeCard.click();
        buttonAddCard.click();
        inputCVVOfCard.sendKeys(String.valueOf(card.getCvv()));
        inputNumberOfCard.sendKeys(String.valueOf(card.getNumber()));
        inputNameOfCard.sendKeys(card.getName());
        inputDateOfCard.sendKeys(String.valueOf(card.getDate()));
        return this;
    }

    @Override
    public AbstractPage waitForPageToLoad() {
        return super.waitForPageToLoad();
    }
}
