package com.epam.ta.model;
import java.util.Objects;

public class Card {

    public Card(int cvv, String number, String name, int date) {
        this.cvv = cvv;
        this.number = number;
        this.name = name;
        this.date = date;
    }

    public int getCvv() {
        return cvv;
    }

    public void setCvv(int cvv) {
        this.cvv = cvv;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getDate() {
        return date;
    }

    public void setDate(int date) {
        this.date = date;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Card)) return false;
        Card card = (Card) o;
        return cvv == card.cvv && date == card.date && number.equals(card.number) && name.equals(card.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(cvv, number, name, date);
    }

    private int cvv;
        private String number;
        private String name;
        private int date;
}
