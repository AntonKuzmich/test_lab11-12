package com.epam.ta.page;
import com.epam.ta.model.Ticket;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.security.Key;


public class AliCategoryPage extends AbstractPage {

    @FindBy(xpath = "//input[@class='snow-ali-kit_Input__inputField__1aiyxh']")
    WebElement inputPrice;



    public AliCategoryPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        logger.info("Opened HomePage");
    }

    public AliCategoryPage AddTicket(Ticket ticket) {
        inputPrice.sendKeys(String.valueOf(ticket.getPrice()));
        return this;
    }
}
