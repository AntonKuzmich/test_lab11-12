package com.epam.ta.page;
import com.epam.ta.model.Adress;
import com.epam.ta.model.Ticket;
import com.epam.ta.model.User;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class AliAccountPage extends AbstractPage {

    @FindBy(xpath = "/html/body/div/div/div[4]/div/div/div/div/div/div[2]/div/nav/ul/li[1]")
    WebElement linkLogOnAccount;
    @FindBy(xpath = "//a[@class='SnowMenu_ListElement__wrapper__1va9a' and @href='https://msg.aliexpress.ru']")
    WebElement linkMessage;
    @FindBy(xpath = "//a[@class='SnowMenu_ListElement__wrapper__1va9a' and @href='https://aliexpress.ru/address-list']")
    WebElement linkAdress;
    @FindBy(xpath = "//button[1][@class='snow-ali-kit_Button-Tertiary__button__jio9gc snow-ali-kit_Button__button__1yq34d snow-ali-kit_Button__sizeS__1yq34d AddressList_AddressCard__button__1e48i']")
    WebElement linkAdressChange;
    @FindBy(xpath = "//input[@name='contactPerson']")
    WebElement inputNameOnAdress;

    @FindBy(xpath = "//input[@name='zip']")
    WebElement inputZipOnAdress;

    @FindBy(xpath = "//input[@name='province']")
    WebElement inputRegionOnAdress;

    @FindBy(xpath = "//input[@name='address']")
    WebElement inputStreetOnAdress;

    @FindBy(xpath = "//input[@name='city']")
    WebElement inputCityOnAdress;

    @FindBy(xpath = "//input[@name='address2']")
    WebElement inputFlatOnAdress;

    @FindBy(xpath = "//input[@name='mobileNo']")
    WebElement inputNumberOnAdress;


    @FindBy(xpath = "/html/body/div[3]/div[2]/div/div[2]/div[3]/div/form/div[2]/label/div/input")
    WebElement UsernameOnAccount;

    @FindBy(xpath = "/html/body/div[3]/div[2]/div/div[2]/div[3]/div/form/div[3]/label/div/input")
    WebElement PasswordOnAccount;

    @FindBy(xpath = "/html/body/div/div/div[4]/div/div/div/div[1]/nav/div[5]/a")
    WebElement linkLogoutFromAccount;

    @FindBy(xpath = "/html/body/div[3]/div[2]/div/div[2]/div[3]/div/form/button")
    WebElement EnterOnAccountButton;

    public AliAccountPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        logger.info("Opened HomePage");
    }

    public AliAccountPage sendMessage() {
        linkMessage.click();
        return this;
    }
    public AliAccountPage loginIntoAccount(User user){
        linkLogOnAccount.click();
        UsernameOnAccount.sendKeys(user.getUsername());
        PasswordOnAccount.sendKeys(user.getPassword());
        EnterOnAccountButton.click();
        return this;
    }

    public AliAccountPage clickLogOutButton() {
        linkLogoutFromAccount.click();
        return this;
    }
    public AliAccountPage changeAdress(Adress adress) throws InterruptedException {
        linkAdress.click();
        linkAdressChange.click();
        Thread.sleep(3000);
        inputNameOnAdress.sendKeys(adress.getName());
        inputNumberOnAdress.sendKeys(String.valueOf(adress.getNumber()));
        inputStreetOnAdress.sendKeys(adress.getStreet());
        inputFlatOnAdress.sendKeys(String.valueOf(adress.getFlat()));
        inputCityOnAdress.sendKeys(adress.getCity());
        inputZipOnAdress.sendKeys(String.valueOf(adress.getZip()));
        return this;
    }

    @Override
    public AbstractPage waitForPageToLoad() {
        return super.waitForPageToLoad();
    }
}
