package com.epam.ta.page;
import com.epam.ta.model.User;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class AliAccountPage extends AbstractPage {

    @FindBy(xpath = "/html/body/div/div/div[4]/div/div/div/div/div/div[2]/div/nav/ul/li[1]")
    WebElement linkLogOnAccount;

    @FindBy(xpath = "/html/body/div[3]/div[2]/div/div[2]/div[3]/div/form/div[2]/label/div/input")
    WebElement UsernameOnAccount;

    @FindBy(xpath = "/html/body/div[3]/div[2]/div/div[2]/div[3]/div/form/div[3]/label/div/input")
    WebElement PasswordOnAccount;

    @FindBy(xpath = "/html/body/div/div/div[4]/div/div/div/div[1]/nav/div[5]/a")
    WebElement linkLogoutFromAccount;

    @FindBy(xpath = "/html/body/div[3]/div[2]/div/div[2]/div[3]/div/form/button")
    WebElement EnterOnAccountButton;

    public AliAccountPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        logger.info("Opened HomePage");
    }

    public AliAccountPage loginIntoAccount(User user){
        linkLogOnAccount.click();
        UsernameOnAccount.sendKeys(user.getUsername());
        PasswordOnAccount.sendKeys(user.getPassword());
        EnterOnAccountButton.click();
        return this;
    }

    public AliAccountPage clickLogOutButton() {
        linkLogoutFromAccount.click();
        return this;
    }
}
