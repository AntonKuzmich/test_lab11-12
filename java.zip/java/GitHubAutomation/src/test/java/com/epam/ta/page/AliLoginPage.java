package com.epam.ta.page;

import com.epam.ta.model.Search;
import com.epam.ta.model.User;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AliLoginPage extends AbstractPage {

    @FindBy(xpath = "/html/body/div[1]/div/div[3]/div/div[1]/div[3]/div/form/div[3]/label/div/input")
    WebElement UsernameOnAccount;

    @FindBy(xpath = "/html/body/div[1]/div/div[3]/div/div[1]/div[3]/div/form/div[2]/label/div/input")
    WebElement PasswordOnAccount;

    @FindBy(xpath = "/html/body/div[1]/div/div[3]/div/div[1]/div[3]/div/form/button")
    WebElement EnterOnAccountButton;

    public AliLoginPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        logger.info("Opened HomePage");
    }

    public AliLoginPage openPage() {
        driver.get(LOGIN_URL);
        new WebDriverWait(driver, WAIT_TIMEOUT_SECONDS);
        return this;
    }
    public AliLoginPage loginIntoAccount(User user) throws InterruptedException {
        UsernameOnAccount.sendKeys(user.getUsername());
        PasswordOnAccount.sendKeys(user.getPassword());
        EnterOnAccountButton.click();
        return this;
    }

    public AliLoginPage waitForHomePageToLoad() {
        new WebDriverWait(driver, WAIT_TIMEOUT_SECONDS);
        return this;
    }

    @Override
    public AbstractPage waitForPageToLoad() {
        return super.waitForPageToLoad();
    }
}