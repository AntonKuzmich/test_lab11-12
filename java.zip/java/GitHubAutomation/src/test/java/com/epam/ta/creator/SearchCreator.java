package com.epam.ta.creator;

import com.epam.ta.model.Search;
import com.epam.ta.util.TestDataReader;

public class SearchCreator {
    public static String TESTDATA_SEARCH_TEXT = "testdata.search.searchText";

    public static Search getSearchWithAllData(){
        return new Search(
                TestDataReader.getTestData(TESTDATA_SEARCH_TEXT)
        );
    }
    public static Search getSearchText(Search search) {
        search.setSearchText(TestDataReader.getTestData(TESTDATA_SEARCH_TEXT));
        return search;
    }
}
