package com.epam.ta.creator;

import com.epam.ta.model.User;
import com.epam.ta.util.TestDataReader;

public class UserCreator {

    public static String TESTDATA_USER_USERNAME = "testdata.user.username";
    public static String TESTDATA_USER_PASSWORD = "testdata.user.password";

    public static User getUserWithAllData(){
return new User(
        TestDataReader.getTestData(TESTDATA_USER_PASSWORD),
        TestDataReader.getTestData(TESTDATA_USER_USERNAME));
    }
}
