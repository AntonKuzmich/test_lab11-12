package com.epam.ta.model;
import java.util.Objects;

public class Ticket {
    public Ticket(int capacity, String ticket, int price) {
        this.capacity = capacity;
        this.ticket = ticket;
        this.price = price;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public String getTicket() {
        return ticket;
    }

    public void setTicket(String ticket) {
        this.ticket = ticket;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Ticket)) return false;
        Ticket ticket1 = (Ticket) o;
        return capacity == ticket1.capacity && price == ticket1.price && ticket.equals(ticket1.ticket);
    }

    @Override
    public int hashCode() {
        return Objects.hash(capacity, ticket, price);
    }

    private int capacity;
    private String ticket;
    private int price;
}
