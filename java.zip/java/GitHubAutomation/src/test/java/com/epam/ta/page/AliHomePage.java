package com.epam.ta.page;

import com.epam.ta.model.Search;
import com.epam.ta.model.User;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AliHomePage extends AbstractPage {

    @FindBy(xpath = "//a[@class='snow-ali-kit_Typography__link__1shggo snow-ali-kit_Typography__link__1shggo snow-ali-kit_Typography__underline__1shggo SnowHeaderProfileItem_Avatar__root__1vhua']")
    WebElement aliAccountPage;
    @FindBy(xpath = "/html/body/div/div/div[4]/div/div/div/div/div/div[2]/div/nav/ul/li[1]")
    WebElement linkLogOnAccount;
    @FindBy(xpath = "/html/body/div[3]/div[2]/div/div[2]/div[3]/div/form/div[3]/label/div/input")
    WebElement UsernameOnAccount;

    @FindBy(xpath = "/html/body/div[3]/div[2]/div/div[2]/div[3]/div/form/div[2]/label/div/input")
    WebElement PasswordOnAccount;


    @FindBy(xpath = "/html/body/div/div/div[4]/div/div/div/div[1]/nav/div[5]/a")
    WebElement linkLogoutFromAccount;

    @FindBy(xpath = "/html/body/div[3]/div[2]/div/div[2]/div[3]/div/form/button")
    WebElement EnterOnAccountButton;

    @FindBy(xpath = "/html/body/div/div/div[4]/div/div/div/div/div/div[2]/div/nav/ul/li[1]")
    WebElement aliAccountPageNoLog;

    @FindBy(xpath = "//a[@href='https://shoppingcart.aliexpress.ru/shopcart/shopcartDetail.htm']")
    WebElement aliBasketPage;

    @FindBy(xpath = "//a[@href='https://aliexpress.ru/order-list']")
    WebElement aliOrderPage;

    @FindBy(xpath = "//a[@class='snow-ali-kit_Typography__link__1shggo snow-ali-kit_Typography__link__1shggo snow-ali-kit_Typography__strong__1shggo snow-ali-kit_Typography__underline__1shggo SnowCategoriesMenu_CategoryItem__link__1mvfx']")
    WebElement aliCategoryPage;

    @FindBy(xpath = "//input[@class='SnowCommonHeader_SnowSearchBar__input__1rg75']")
    WebElement searchThing;


    public AliHomePage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        logger.info("Opened HomePage");
    }
    public AliHomePage loginIntoAccount(User user) throws InterruptedException {
        linkLogOnAccount.click();
        UsernameOnAccount.sendKeys(user.getUsername());
        PasswordOnAccount.sendKeys(user.getPassword());
        EnterOnAccountButton.click();
        return this;
    }


    public AliHomePage openPage() {
        driver.get(HOMEPAGE_URL);
        new WebDriverWait(driver, WAIT_TIMEOUT_SECONDS);
        return this;
    }


    public AliHomePage openAccountPage() {
        aliAccountPage.click();
        return this;
    }
    public AliHomePage openAccountPageNoLog(){
        aliAccountPageNoLog.click();
        return this;
    }
    public AliHomePage openBasketPage() {
        aliBasketPage.click();
        return this;
    }
    public AliHomePage openCategoryPage() {
        aliCategoryPage.click();
        return this;
    }
    public AliHomePage openOrderPage() {
        aliOrderPage.click();
        return this;
    }
    public AliHomePage searchThing(Search search) {
        searchThing.sendKeys(search.getSearchText()+ Keys.ENTER);
        return this;
    }
    public AliHomePage waitForHomePageToLoad() {
        new WebDriverWait(driver, WAIT_TIMEOUT_SECONDS);
        return this;
    }

    @Override
    public AbstractPage waitForPageToLoad() {
        return super.waitForPageToLoad();
    }
}