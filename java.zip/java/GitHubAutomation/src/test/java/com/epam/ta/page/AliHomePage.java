package com.epam.ta.page;

import com.epam.ta.model.Search;
import com.epam.ta.model.User;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AliHomePage extends AbstractPage {

    @FindBy(xpath = "/html/body/div/div/div[4]/div/div/div/div/div/div[2]/div/nav/ul/li[1]/a")
    WebElement aliAccountPage;
    @FindBy(xpath = "/html/body/div/div/div[4]/div/div/div/div/div/div[2]/div/nav/ul/li[1]")
    WebElement linkLogOnAccount;
    @FindBy(xpath = "/html/body/div[3]/div[2]/div/div[2]/div[3]/div/form/div[2]/label/div/input")
    WebElement UsernameOnAccount;

    @FindBy(xpath = "/html/body/div[3]/div[2]/div/div[2]/div[3]/div/form/div[3]/label/div/input")
    WebElement PasswordOnAccount;

    @FindBy(xpath = "/html/body/div/div/div[4]/div/div/div/div[1]/nav/div[5]/a")
    WebElement linkLogoutFromAccount;

    @FindBy(xpath = "/html/body/div[3]/div[2]/div/div[2]/div[3]/div/form/button")
    WebElement EnterOnAccountButton;

    @FindBy(xpath = "/html/body/div/div/div[4]/div/div/div/div/div/div[2]/div/nav/ul/li[1]")
    WebElement aliAccountPageNoLog;

    @FindBy(xpath = "/html/body/div/div/div[4]/div/div/div/div/div/div[2]/div/nav/ul/li[3]/a")
    WebElement aliBasketPage;

    @FindBy(xpath = "/html/body/div/div/div[4]/div/div/div/div/div/div[2]/div/nav/ul/li[2]/a")
    WebElement aliOrderPage;

    @FindBy(xpath = "/html/body/div/div/div[6]/div/div/div/div[1]/div/ul/li[3]/a")
    WebElement aliCategoryPage;

    @FindBy(xpath = "/html/body/div/div/div[4]/div/div/div/div/div/div[2]/div/div/div/div[2]/div[2]/div/input")
    WebElement searchThing;

    @FindBy(xpath = "/html/body/div/div/div[4]/div/div/div/div/div/div[2]/div/div/div/div[2]/div[2]/div/label")
    WebElement searchThingButton;

    public AliHomePage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        logger.info("Opened HomePage");
    }
    public AliHomePage loginIntoAccount(User user){
        linkLogOnAccount.click();
        UsernameOnAccount.sendKeys(user.getUsername());
        PasswordOnAccount.sendKeys(user.getPassword());
        EnterOnAccountButton.click();
        return this;
    }


    public AliHomePage openPage() {
        driver.get(HOMEPAGE_URL);
        new WebDriverWait(driver, WAIT_TIMEOUT_SECONDS);
        return this;
    }


    public AliHomePage openAccountPage() {
        aliAccountPage.click();
        return this;
    }
    public AliHomePage openAccountPageNoLog(){
        aliAccountPageNoLog.click();
        return this;
    }
    public AliHomePage openBasketPage() {
        aliBasketPage.click();
        return this;
    }
    public AliHomePage openCategoryPage() {
        aliOrderPage.click();
        return this;
    }
    public AliHomePage openOrderPage() {
        aliCategoryPage.click();
        return this;
    }
    public AliHomePage searchThing(Search search) {
        searchThing.sendKeys(search.getSearchText());
        searchThingButton.click();
        return this;
    }
    public AliHomePage waitForHomePageToLoad() {
        new WebDriverWait(driver, WAIT_TIMEOUT_SECONDS);
        return this;
    }
}