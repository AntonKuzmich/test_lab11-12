package com.epam.ta.driver;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.WebDriver.Options;
import org.openqa.selenium.firefox.FirefoxDriver;


public class DriverSingleton {
    private static WebDriver driver;
    static ChromeOptions chromeoptions=new ChromeOptions();

    private DriverSingleton() { }

    public static WebDriver getDriver() {
                    WebDriverManager.chromedriver().setup();
                    chromeoptions.addArguments("user-data-dir=C:\\Users\\anton\\AppData\\Local\\Google\\Chrome\\User Data\\Default");
                    driver = new ChromeDriver(chromeoptions);
            driver.manage().window().maximize();
        return driver;
    }


    public static void closeDriver() {
        driver.quit();
        driver = null;
    }
}
