package com.epam.ta.model;

import java.util.Objects;

public class Search {

    public String getSearchText() {
        return searchText;
    }

    public void setSearchText(String request) {
        this.searchText = searchText;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Search)) return false;
        Search search = (Search) o;
        return searchText.equals(search.searchText);
    }

    @Override
    public int hashCode() {
        return Objects.hash(searchText);
    }

    public Search(String searchText) {
        this.searchText = searchText;
    }

    private String searchText;
}
