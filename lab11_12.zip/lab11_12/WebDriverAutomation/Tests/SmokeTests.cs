﻿using NUnit.Framework;

namespace WebDriverAutomation.Tests;

[TestFixture]
public class SmokeTests
{
    private Steps.Steps _steps = new Steps.Steps();

    [SetUp]
    public void Init()
    {
        _steps.InitBrowser();
    }

    [TearDown]
    public void Cleanup()
    {
        _steps.CloseBrowser();
    }
    [Test]
    public void OneCanSignUpaliexpress()
    {
        _steps.SignUpaliexpress();
    }
    [Test]
    public void FindSomeThing1()
    {
        _steps.FindSomeThing1();
    }
    [Test]
    public void FindSomeThing2()
    {
        _steps.FindSomeThing2();
    }
    [Test]
    public void FindSomeThing3()
    {
        _steps.FindSomeThing3();
    }
    [Test]
    public void FindSomeThing4()
    {
        _steps.FindSomeThing4();
    }
}