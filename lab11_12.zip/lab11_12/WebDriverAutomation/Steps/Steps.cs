﻿using OpenQA.Selenium;
using WebDriverAutomation.Pages;

namespace WebDriverAutomation.Steps;

public class Steps
{
    IWebDriver driver;

    public void InitBrowser()
    {
        driver = Driver.DriverInstance.GetInstance();
    }

    public void CloseBrowser()
    {
        Driver.DriverInstance.CloseBrowser();
    }

    public void SignUpaliexpress()
    {
        var find5 = new find5(driver);
        find5.OpenPage();
        find5.SignIn();
    }
    public void FindSomeThing1()
    {
        var find1 = new Find1(driver);
        find1.OpenPage();
        find1.SignIn();
    }
    public void FindSomeThing2()
    {
        var find2 = new Find2(driver);
        find2.OpenPage();
        find2.SignIn();
    }
    public void FindSomeThing3()
    {
        var find3 = new Find3(driver);
        find3.OpenPage();
        find3.SignIn();
    }
    public void FindSomeThing4()
    {
        var find4 = new Find4(driver);
        find4.OpenPage();
        find4.SignIn();
    }
}