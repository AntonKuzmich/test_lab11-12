﻿using OpenQA.Selenium;
using SeleniumExtras.PageObjects;

namespace WebDriverAutomation.Pages;

public class HomePage
{
    private const string BASE_URL = "https://aliexpress.ru/";

    private IWebDriver _driver;

    [FindsBy(How = How.XPath, Using = "/html/body/div/div/div[4]/div/div/div/div/div/div[2]/div/div/div/div[2]/div[2]/div[1]/input")]
    private IWebElement _searchBar;

    [FindsBy(How = How.XPath, Using = "/html/body/div/div/div[4]/div/div/div/div/div/div[1]/div/a")]
    private IWebElement _callbackLink;

    [FindsBy(How = How.XPath, Using = "/html/body/div[1]/div/div[4]/div/div/div/div/div/div[2]/div/nav/ul/li[1]")]
    private IWebElement _signUpAndSignInButton;

    public HomePage(IWebDriver driver)
    {
        this._driver = driver;
        PageFactory.InitElements(this._driver, this);
    }

    public void OpenPage()
    {
        _driver.Navigate().GoToUrl(BASE_URL);
    }
}
