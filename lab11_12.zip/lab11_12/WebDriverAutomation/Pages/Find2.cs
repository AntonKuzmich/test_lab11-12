﻿using OpenQA.Selenium;
using SeleniumExtras.PageObjects;

namespace WebDriverAutomation.Pages;

public class Find2
{
    private const string BASE_URL = "https://aliexpress.ru/";



    [FindsBy(How = How.XPath, Using = "/html/body/div/div/div[6]/div/div/div/div[1]/div/ul/li[1]/a")]
    private IWebElement _signInButton3;


    [FindsBy(How = How.XPath, Using = "/html/body/div/div/div[6]/div/div/div/div[2]/div[1]/div/a[2]")]
    private IWebElement _signInButton4;



    private IWebDriver _driver;

    public Find2(IWebDriver driver)
    {
        this._driver = driver;
        PageFactory.InitElements(this._driver, this);
    }

    public void OpenPage()
    {
        _driver.Navigate().GoToUrl(BASE_URL);
        Console.WriteLine("Login page opened");
    }

    public void SignIn()
    {
        _signInButton3.Click();
        _signInButton4.Click();
    }
}